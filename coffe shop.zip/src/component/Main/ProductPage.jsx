import { useState, useEffect } from "react";
import axios from "axios";

function ProductPage() {
  const [mehsul, setMehsul] = useState([]);
  const [error, setError] = useState("");

  // Məhsul məlumatlarını API-dən almaq üçün funksiyanı çağırırıq
  useEffect(() => {
    async function GetProduct() {
      try {
        const res = await axios.get("https://finalprojectt-001-site1.jtempurl.com/api/Product");
        setMehsul(res.data); // Məhsul məlumatlarını state-də saxlayırıq
      } catch (err) {
        console.error("Məhsul məlumatlarını alarkən xəta baş verdi:", err);
        setError("Məhsul məlumatları yüklənərkən xəta baş verdi."); // Xətanı istifadəçiyə bildiririk
      }
    }

    GetProduct(); // API-yə sorğu göndəririk
  }, []);

  // Məhsul məlumatları yoxdursa, yüklənir mesajını göstəririk
  if (error) {
    return <div>{error}</div>; // Xəta mesajını göstəririk
  }

  if (mehsul.length === 0) {
    return <div>Yüklənir...</div>; // Məhsul məlumatları yüklənərkən göstərilən mesaj
  }

  return (
    <div className="py-32">
      <h1>Məhsullar</h1>
      {mehsul.map((product) => (
        <div key={product.id}>
          <h2>{product.title}</h2>
          <img
            src={`https://finalprojectt-001-site1.jtempurl.com${product.imgUrl}`}
            alt={product.title}
          />
          <p>{product.about}</p>
          <p>Qiymət: {product.price} ₼</p>
        </div>
      ))}
    </div>
  );
}

export default ProductPage;
